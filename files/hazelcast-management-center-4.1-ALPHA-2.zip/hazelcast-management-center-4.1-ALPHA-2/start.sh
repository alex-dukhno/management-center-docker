#!/bin/sh

if [ "$1" = "--help" ] || [ $# -gt 3 ] ; then
    echo "usage: start.sh"
    echo "usage: start.sh [port]"
    echo "usage: start.sh [port] [context path]"
    echo "usage: start.sh [port] [context path] [classpath]"
    exit;
fi

if [ $# -eq 3 ] ; then
    # shellcheck disable=SC2154
    java $JAVA_OPTS "-Dhazelcast.mc.http.port=$1" "-Dhazelcast.mc.contextPath=$2" \
    -cp "hazelcast-management-center-4.1-ALPHA-2.jar:$3" com.hazelcast.webmonitor.Launcher
elif [ $# -eq 2 ] ; then
    java $JAVA_OPTS "-Dhazelcast.mc.http.port=$1" "-Dhazelcast.mc.contextPath=$2" \
    -cp "hazelcast-management-center-4.1-ALPHA-2".jar com.hazelcast.webmonitor.Launcher
elif [ $# -eq 1 ] ; then
    java $JAVA_OPTS "-Dhazelcast.mc.http.port=$1" -cp "hazelcast-management-center-4.1-ALPHA-2".jar \
    com.hazelcast.webmonitor.Launcher
else
    java $JAVA_OPTS -cp "hazelcast-management-center-4.1-ALPHA-2".jar com.hazelcast.webmonitor.Launcher
fi
