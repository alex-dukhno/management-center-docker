#!/bin/sh

java $JAVA_OPTS -cp hazelcast-management-center-4.0.3-SNAPSHOT.war com.hazelcast.webmonitor.cli.MCConfCommandLine "$@"
