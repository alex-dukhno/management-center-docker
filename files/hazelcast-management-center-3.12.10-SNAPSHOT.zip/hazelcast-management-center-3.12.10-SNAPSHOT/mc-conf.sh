#!/bin/sh

java $JAVA_OPTS -cp hazelcast-mancenter-3.12.10-SNAPSHOT.war com.hazelcast.webmonitor.cli.MCConfCommandLine "$@"
