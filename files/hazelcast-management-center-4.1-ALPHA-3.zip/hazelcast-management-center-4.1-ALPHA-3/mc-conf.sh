#!/bin/sh

java $JAVA_OPTS -cp hazelcast-management-center-4.1-ALPHA-3.jar com.hazelcast.webmonitor.cli.MCConfCommandLine "$@"
